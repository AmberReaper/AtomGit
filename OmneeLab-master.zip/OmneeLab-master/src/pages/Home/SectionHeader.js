import React, { useRef } from "react";

import "./SectionHeader.scss";
import homebg from "../../assets/images/header-background.jpg";

const SectionHeader = () => {
  return (
    <div className="homeHeader ">
      <div className="headingContainer text-center">
        <h1 className="headingMain text-white margin-zero">
          Next Generation <br /> Warehouse Management System
        </h1>
        <hr className="hrPrimary" />
        <h2 className="headingSmall text-white margin-zero">
          Achieve more by leaving complex warehouse and inventory management to
          the expert software
        </h2>
        <a href="#sectionAbout">
          <button className="btn btn--primary text-white u-margin-top-medium">
            Lets Get Started
          </button>
        </a>

        <a href="#sectionAbout" className="scrollArrow">
          <span className="u-margin-top-small"></span>
        </a>
      </div>
    </div>
  );
};

export default SectionHeader;
