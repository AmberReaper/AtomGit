import React, { Children } from "react";

import "./Testimonial.scss";

import TestimonialList from "./TestimonialList";
import Slideshow from "../Slideshow/Slideshow";

const Testimonial = (props) => {
  return <div className="testimonial">{props.children}</div>;
};

export default Testimonial;
