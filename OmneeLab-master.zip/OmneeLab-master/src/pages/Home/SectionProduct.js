import React from "react";
import { Link } from "react-router-dom";

import "./SectionProduct.scss";

import DashboardMobile from "../../assets/images/dashboard-mobile.jpg";

const SectionProduct = () => {
  return (
    <div className="sectionProduct">
      <div className="col-1-of-2 leftContainer">
        <div className="imagePhoneContainer">
          <img className="imagePhone" src={DashboardMobile} alt="mobile" />
        </div>
      </div>

      <div className="col-1-of-2 rightContainer">
        <h1 className="headingPrimary text-white margin-zero">
          We Believe in Efficiency
        </h1>

        <hr className="hrPrimary"></hr>

        <p className="text-white normal-text productDef ">
          Does it sometimes feel that you are wasting a lot of time in locating
          goods in your warehouse or there have been lot of issue in inventory
          totaling lately? <br />
          <br />
          Digitize these Warehouse Operations using our AI powered WMS solution
          and see the results. Our WMS will not only help you optimize these
          operations but also run the entire process efficiently.
        </p>

        <Link to="/whyOmneelab">
          <button className="btn btn--secondary ">Read More</button>
        </Link>
      </div>
    </div>
  );
};
export default SectionProduct;
