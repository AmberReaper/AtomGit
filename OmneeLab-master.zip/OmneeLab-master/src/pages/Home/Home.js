import React from "react";

import SectionHeader from "./SectionHeader";
import SectionAbout from "./SectionAbout";
import SectionProduct from "./SectionProduct";
import SectionContact from "./SectionContact";

import Testimonial from "../../components/Testimonial/Testimonial";

import "./Home.scss";

const Home = () => {
  return (
    <div className="homeContainer">
      <SectionHeader />
      <SectionAbout />
      <SectionProduct />
      <Testimonial>
        <p className="testimonial-text ">
          The team is highly proficient and knows the industry and its
          challenges inside out. Clearly they are not just the software guys but
          have actually been on the other side of the fence and understand
          warehouse operations challenges very well. The solutions they provide
          are truly remarkable and to the point.
        </p>
        <div className="testimonial-info">
          <span>- Operations Manager</span>, a Leading Distributor
        </div>
      </Testimonial>
      <SectionContact />
    </div>
  );
};

export default Home;
