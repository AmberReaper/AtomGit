import React from "react";

import "./Integration.scss";

import Amazon from "../../assets/images/amazon.png";
import Flipkart from "../../assets/images/flipkart.png";
import Snapdeal from "../../assets/images/snapdeal.png";
import Rivigo from "../../assets/images/rivigo.jpg";
import Navi from "../../assets/images/NAV.png";
import MS from "../../assets/images/ms-business-central.png";
import Delhivery from "../../assets/images/delhivery.jpg";
import Fedex from "../../assets/images/fedex_logo.png";
import Gati from "../../assets/images/Gati.png";

const Integrations = () => {
  return (
    <div className="integrations">
      <h1 className="headingPrimary margin-zero">Our Integrations</h1>
      <h2 className="headingSecondary headingColor">
        Our WMS is integrable to a large number of supply chain partners and
        tools available
      </h2>

      <div className="integrationsList">
        <div>
          <img src={Amazon}></img>
          <img src={Flipkart}></img>
          <img src={Snapdeal}></img>
        </div>
        <div>
          <img src={Delhivery}></img>
          <img src={Fedex}></img>
          <img src={Gati}></img>
          <img src={Rivigo}></img>
        </div>
        <div>
          <img src={Navi}></img>
          <img src={MS}></img>
        </div>
      </div>
    </div>
  );
};

export default Integrations;
