const MenuItems = [
  {
    title: "Home",
    route: "",
  },
  {
    title: "Why Omneelab",
    route: "whyOmneelab",
  },
  {
    title: "About Us",
    route: "about",
  },
  {
    title: "Contact Us",
    route: "contact",
  },
  {
    title: "Request a Demo",
    route: "contact",
  },
];

export default MenuItems;
