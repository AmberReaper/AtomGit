import React, { useState } from "react";
import { Link } from "react-router-dom";

import "./Footer.scss";

import MenuItems from "../Navbar/MenuItems";

const Footer = () => {
  return (
    <div className="footer">
      <div className="socials">
        <p className="text-white">Connect with us </p>
        <span>
          <a
            target="_blank"
            href="https://in.linkedin.com/company/omneelab-wms"
            className="text-white"
          >
            <i className="fab fa-linkedin"></i>
          </a>
          <a
            target="_blank"
            href="https://www.facebook.com/OmneelabWMS/"
            className="text-white"
          >
            <i className="fab fa-facebook"></i>
          </a>
          <a
            target="_blank"
            href="https://www.youtube.com/channel/UCOXkxUT3phAi7Vyh9JqOltA/"
            className="text-white"
          >
            <i className="fab fa-youtube"></i>
          </a>

          <i className="text-white fab fa-twitter"></i>

          <i className="text-white fab fa-instagram"></i>
        </span>
      </div>
      <div className="footerBody text-white">
        <ul className="footerNav ">
          {MenuItems.map((item) => {
            return (
              <li key={item.title}>
                <Link to={`/${item.route}`} className="text-white">
                  {item.title}
                </Link>
              </li>
            );
          })}
        </ul>
        <p className="copyright text-center u-margin-top-small">
          &copy; 2019 Omneelab Software Solutions Pvt. Ltd. All Rights Reserved.
        </p>
      </div>
    </div>
  );
};

export default Footer;
