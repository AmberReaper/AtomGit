import { Suspense, lazy } from "react";
import { Switch, Route, useParams } from "react-router-dom";

import Navbar from "./components/Navbar/Navbar";
import Footer from "./components/Footer/Footer";
import NotFound from "./components/404/404";

import Home2 from "./pages/Home/Home";
import Contact2 from "./pages/Contact/Contact";
import About2 from "./pages/About/About";
import WhyOmneeLab2 from "./pages/WhyOmneeLab/WhyOmneeLab";

import "./App.css";

const Home = lazy(() => import("./pages/Home/Home"));
const Contact = lazy(() => import("./pages/Contact/Contact"));
const About = lazy(() => import("./pages/About/About"));
const WhyOmneeLab = lazy(() => import("./pages/WhyOmneeLab/WhyOmneeLab"));

function App() {
  return (
    <div className="App">
      <Suspense fallback={"none"}>
        <Navbar />
        <Switch>
          <Route exact path="/" component={Home2} />
          <Route path="/contact" component={Contact2} />
          <Route path="/whyOmneelab" component={WhyOmneeLab2} />
          <Route path="/about" component={About2} />
          <Route component={NotFound} />
        </Switch>
        <Footer />
      </Suspense>
    </div>
  );
}

export default App;
