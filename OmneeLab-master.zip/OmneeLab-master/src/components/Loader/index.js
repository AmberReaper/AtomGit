import { createPortal } from "react-dom";

import "./Loader.css";

const Loader = () => {
  return createPortal(
    <div className="shown">
      <div className="blobs">
        <div className="blob-center"></div>
        <div className="blob"></div>
        <div className="blob"></div>
        <div className="blob"></div>
        <div className="blob"></div>
        <div className="blob"></div>
        <div className="blob"></div>
      </div>
    </div>,
    document.getElementById("loader")
  );
};

export default Loader;
