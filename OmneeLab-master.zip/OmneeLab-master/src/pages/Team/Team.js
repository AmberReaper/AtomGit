import React from "react";

import TeamMembers from "./TeamMember";
import teamPhoto from "../../assets/images/team1.jpg";
import "./Team.scss";

const Team = () => {
  return (
    <div className="teamContainer">
      <div className="teamHeader">
        <h1 className="headingMain text-white center margin-zero">
          Meet Our Team
        </h1>
      </div>

      <div className="Heading text-center teamHeading">
        <h2 className="headingSecondary text-uppercase font-bold headingColor margin-zero">
          Our Team
        </h2>
        <h1 className="headingPrimary margin-zero">
          Together Everyone Achieves More
        </h1>
      </div>

      <div className="memberContainer container">
        {TeamMembers.map((item) => {
          return (
            <div className="member" key={item.name}>
              <img className="teamPhoto" src={teamPhoto}></img>
              <h2 className="memberName margin-zero">{item.name}</h2>
              <h3 className="memberDesignation margin-zero">
                {item.designation}
              </h3>
              <a href={item.linkedinUrl}>
                <i className="fab fa-linkedin socialHandle"></i>
              </a>
              <a href={item.TwitterUrl}>
                <i className="fab fa-twitter-square socialHandle"></i>
              </a>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Team;
