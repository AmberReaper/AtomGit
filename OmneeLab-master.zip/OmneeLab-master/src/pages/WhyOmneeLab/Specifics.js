import React from "react";

import "./Specifics.scss";

const Specifics = () => {
  return (
    <div className="specifics">
      <h1 className="headingPrimary">Our Key Features</h1>
      <div className="container">
        <div className="listHead">
          <h2 className="headingMedium headingColor">Generic</h2>
          <ul className="keyList">
            <li>Specific location/Bin level inventory Info</li>
            <li>Multi-Location/Site Transfer</li>
            <li>Multi-Company/3PL</li>
            <li>Multi-Channel</li>
            <li>Full Item tracking (Lot/Serial) Support</li>
            <li>Multiple Units of Measure</li>
            <li>Break Bulk</li>
            <li>Expiry Tracking</li>
          </ul>
        </div>
        <div className="listHead">
          <h2 className="headingMedium headingColor">Inward</h2>
          <ul className="keyList">
            <li>Order Management</li>
            <li>Individual or consolidated receiving</li>
            <li>ASN</li>
            <li>Gate Entry</li>
            <li>QC</li>
            <li>Warehouse Receipts</li>
            <li>Put-away</li>
          </ul>
        </div>

        <div className="listHead">
          <h2 className="headingMedium headingColor">Outward</h2>
          <ul className="keyList">
            <li>Multi Zone picking</li>
            <li>Full Picking and Packaging</li>
            <li>Wave Picking</li>
            <li>Order allocation</li>
            <li>Packing</li>
            <li>Manifest</li>
            <li>Break Bulk</li>
            <li>Warehouse Shipments</li>
          </ul>
        </div>
        <div className="listHead">
          <h2 className="headingMedium headingColor">Warehouse</h2>
          <ul className="keyList">
            <li>Zones</li>
            <li>Bins</li>
            <li>Inventory Movement</li>
            <li>Cycle Inventory Counts</li>
            <li>Bin to Bin Movement</li>
            <li>Kitting</li>
            <li>Physical inventory count</li>
          </ul>
        </div>
        <div className="listHead">
          <h2 className="headingMedium headingColor">Reporting</h2>
          <ul className="keyList">
            <li>Dashboard</li>
            <li>Dynamic reporting tags/field creation</li>
            <li>Pre-configured excel report template</li>
            <li>Auto emailing of reports</li>
            <li>Robust reporting </li>
            <li>Data Analytics</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Specifics;
