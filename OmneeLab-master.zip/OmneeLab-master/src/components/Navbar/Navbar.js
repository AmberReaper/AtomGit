import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";

import logo from "../../assets/images/logo-white.png";
import MenuItems from "./MenuItems";

import "./Navbar.scss";

const Navbar = (props) => {
  const [clicked, setClicked] = useState(false);
  const [changeNav, setChangeNav] = useState(false);

  const handleClick = () => {
    setClicked((clicked) => !clicked);
    console.log(clicked);
  };

  const change = () => {
    if (window.scrollY >= 90) {
      setChangeNav(true);
    } else {
      setChangeNav(false);
    }
  };

  window.addEventListener("scroll", change);

  // let path = useLocation().pathname;

  return (
    <React.Fragment>
      <div id="nav" className={changeNav ? "navbar active" : "navbar"}>
        <span className="logoContainer">
          <Link to="/">
            <img className="logo" src={logo}></img>
          </Link>
        </span>

        <nav className="navDesktop">
          <ul className="navigationList">
            {MenuItems.map((el) => {
              return (
                <li key={el.title}>
                  <Link to={`/${el.route}`}>{el.title}</Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="navIconContainer" onClick={handleClick}>
          <span className={clicked ? "navIcon iconCross" : "navIcon iconBars"}>
            &nbsp;
          </span>
        </div>
      </div>

      <nav
        className="navigation"
        style={{ display: clicked ? "block" : "none" }}
      >
        <ul className="navigation__list text-center">
          {MenuItems.map((item) => {
            return (
              <Link
                key={item.title}
                className="navigation__link"
                to={`/${item.route}`}
                onClick={handleClick}
              >
                {item.title}
              </Link>
            );
          })}
        </ul>
      </nav>
    </React.Fragment>
  );
};

export default Navbar;
