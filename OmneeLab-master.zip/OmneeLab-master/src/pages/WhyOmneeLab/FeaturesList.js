const Features = [
  {
    icon: "fas fa-hand-pointer",
    title: "Easy To Use",
    desc:
      "Although Being Advanced, Our solution has been designed by keeping the customer in mind. It is extremely easy to use and lets the user have full control",
  },
  {
    icon: "fas fa-bolt",
    title: "Lightning Fast",
    desc:
      "Our solution has been built for speed and optimizations. It will help you save a lot of time which you can spend growing your business.",
  },
  {
    icon: "fas fa-wrench",
    title: "Highly Customizable",
    desc:
      "The Solution is completely user centered and can be modified according to the individual needs of the user",
  },
  {
    icon: "fas fa-plus",
    title: "Easy Integrations",
    desc:
      "Our Solution Allows you integrate with a huge number of tools present. ",
  },
  {
    icon: "fas fa-lock",
    title: "Fiercely Secure",
    desc:
      "Security is a key feature of our Solution and has been given utmost attention to. It is one of the most secure WMS Solutions present out there.",
  },
  {
    icon: "fas fa-cloud",
    title: "Cloud Based",
    desc:
      "Our solution is completely cloud based so you will never lose your data due to some issue. ",
  },
];

export default Features;
