import React, { useEffect, useRef, useState } from 'react';
import { useSwipeable } from 'react-swipeable';

import './index.css';

const escapeRegExp = (string) => {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
};

const replaceAll = (str, match, replacement) => {
    return str.replace(new RegExp(escapeRegExp(match), 'g'), () => replacement);
};

const Slideshow = ({
    children,
    autoMove = true,
    totalSlides = 3,
    slideDuration = 2000,
    classes,
    ...rest
}) => {
    const slideshowContainerRef = useRef();

    const [slide, setSlide] = useState(0);

    const nextSlide = () => {
        setSlide((currSlide) =>
            currSlide === totalSlides - 1 ? 0 : currSlide + 1,
        );
    };

    const previousSlide = () => {
        setSlide((currSlide) =>
            currSlide === 0 ? totalSlides - 1 : currSlide - 1,
        );
    };

    const swipeHandlers = useSwipeable({
        onSwipedLeft: () => nextSlide(),
        onSwipedRight: () => previousSlide(),
    });

    useEffect(() => {
        slideshowContainerRef.current.scrollTo(
            slideshowContainerRef.current.clientWidth * slide,
            0,
        );

        if (autoMove) {
            const slideInterval = setInterval(() => nextSlide(), slideDuration);

            return () => clearInterval(slideInterval);
        }

        // eslint-disable-next-line
    }, [slide]);

    return (
        <div
            className={`slideshow d-flex ${
                classes ? replaceAll(classes.toString(), ',', ' ') : ''
            }`}
            {...swipeHandlers}
            {...rest}
        >
            {totalSlides > 1 && (
                <span
                    className='slideshow-controller glass-effect previous d-flex'
                    onClick={previousSlide}
                >
                    <i className='fas fa-chevron-left'></i>
                </span>
            )}
            <div className='slide-container d-flex' ref={slideshowContainerRef}>
                {children.map((childSlide, index) => (
                    <section
                        key={index}
                        className={`slide ${
                            index === slide ? 'active-slide' : ''
                        }`}
                    >
                        {childSlide}
                    </section>
                ))}
            </div>
            {totalSlides > 1 && (
                <span
                    className='slideshow-controller glass-effect next d-flex'
                    onClick={nextSlide}
                >
                    <i className='fas fa-chevron-right'></i>
                </span>
            )}
            <div className='slideshow-dots'>
                {children.map((child, index) => {
                    return (
                        <React.Fragment key={index}>
                            {index === 0 ? (
                                <></>
                            ) : (
                                <div
                                    className={`slideshow-dot-connector background-${
                                        index <= slide
                                            ? 'primary'
                                            : 'light-translucent'
                                    }`}
                                ></div>
                            )}
                            <div
                                className={`slideshow-dot background-${
                                    index <= slide
                                        ? 'primary'
                                        : 'light-translucent'
                                }`}
                                onClick={() => {
                                    setSlide(index);
                                }}
                                style={{
                                    width: index === slide ? '1rem' : '0.75rem',
                                    height:
                                        index === slide ? '1rem' : '0.75rem',
                                }}
                            ></div>
                        </React.Fragment>
                    );
                })}
            </div>
        </div>
    );
};

export default Slideshow;
