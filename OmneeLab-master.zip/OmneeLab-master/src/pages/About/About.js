import React from "react";

import "./About.scss";

import ImgTest from "../../assets/images/test.jpg";
import ImgTest2 from "../../assets/images/test2.jpg";
import ImgTest3 from "../../assets/images/test3.jpg";

const About = () => {
  return (
    <div className="aboutContainer text-center">
      <div className="aboutHeader">
        <h1 className="headingMain text-white center margin-zero">About Us</h1>
      </div>
      <div className="aboutText ">
        <h1 className="headingPrimary margin-zero ">What we do</h1>
        <hr className="hrPrimary" />
        <p className=" text-black">
          Inventory, Warehouse Operations & Fulfilment are integral part of
          sales process but are fragmented. Its management lack technology usage
          to meet increasing customer demands. We digitise Inventory,
          Warehousing Operations and Fulfilment to complement your sales. From
          tracking your orders to processing them and managing your inventory is
          something we have simplified through digitisation
        </p>
      </div>
      <div className="helpContainer">
        <h1 className="headingPrimary margin-zero ">How we Help</h1>
        <hr className="hrPrimary" />
        <div className="helpBox">
          <div className="imageContainer">
            <img src={ImgTest3} alt="test"></img>
            <div className="imageMask"></div>
          </div>
          <div className="helpInformation">
            <div className="informationContainer">
              <h2 className="">Layout & Design of the Warehouse</h2>
              <hr className="hrPrimary" />
              <p>
                Warehouse layout is one of the most neglected areas and one of
                the major reason for low productivity inside the warehouses
                Omneelab WMS help you with :
              </p>
              <ul>
                <li>‘Performing’ layout of the warehouse</li>
                <li>
                  Maximising space utilisation with ‘2D’ and ‘Cube’ mapping of
                  the warehouse
                </li>
                <li>Helps you plan stock put-away based on movement type</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="helpBox">
          <div className="imageContainer hidden">
            <img src={ImgTest} alt="test"></img>
            <div className="imageMask"></div>
          </div>
          <div className="helpInformation">
            <div className="informationContainer">
              <h2 className="">Inventory & Order Management</h2>
              <hr className="hrPrimary" />
              <p>Omneelab WMS helps you :</p>
              <ul>
                <li>
                  Manage multi-client, multi-location inventory through a single
                  dashboard
                </li>
                <li>
                  Integrate with your orders front-end and helps smoothen the
                  order flow process
                </li>
                <li>Order processing based on FIFO / FMFO / LIFO / FEFO</li>
                <li>
                  Manage picking by merging pick lists on pickers / SKUs /
                  locations / zone
                </li>
                <li>Enhance your order fill rate to near 100%</li>
              </ul>
              <p>
                With Omneelab WMS rest assured to enhance efficiency of your
                warehouse and accuracy of your inventory & order processing
              </p>
            </div>
          </div>
          <div className="imageContainer reveal">
            <img src={ImgTest} alt="test"></img>
            <div className="imageMask"></div>
          </div>
        </div>

        <div className="helpBox">
          <div className="imageContainer">
            <img src={ImgTest2} alt="test"></img>
            <div className="imageMask"></div>
          </div>
          <div className="helpInformation">
            <div className="informationContainer">
              <h2 className="">Warehousing & Fulfilment</h2>
              <hr className="hrPrimary" />
              <p>Omneelab WMS equip you with :</p>
              <ul>
                <li>Flexible picking techniques</li>
                <li>
                  Multiple-client inventory with more than one unit of measure
                  (UOM)
                </li>
                <li>Integration to handheld devices like scanners</li>
                <li>Managing Kitting / Bundling / Co-packing</li>
                <li>Enhanced dispatch accuracy</li>
                <li>
                  Managing multi-level hierarchies using a single interface
                </li>
                <li>
                  Integration with Last Mile Providers to get real-time tracking
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="normal-text afterdeploying text-center">
        <h2 className="afterHeading">
          After deploying Omneelab WMS, you will have
        </h2>
        <hr className="hrPrimary" />
        <div className="afterDeployingFeaturesContainer">
          <div className="afterDeployingFeatureBox">
            <i className="fas fa-fast-forward" />
            Faster order processing … and no more pending sales orders for
            processing
          </div>
          <div className="afterDeployingFeatureBox">
            <i className="fas fa-eye" />
            Visibility of slow & fast moving SKUs hence you can plan optimum
            inventory
          </div>
          <div className="afterDeployingFeatureBox">
            <i className="fas fa-boxes" />
            High SKU level inventory visibility thereby no inventory
            obsolescence
          </div>
          <div className="afterDeployingFeatureBox">
            <i className="fas fa-check-square" />
            SKU level inventory visibility to sales team so they sell more
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
