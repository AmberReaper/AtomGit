import React from "react";

import "./404.scss";

import robo from "../../assets/images/robo.png";

const NotFound = () => {
  return (
    <div className="notFoundContainer">
      <div className="notFoundInfo center text-center">
        <img className="notFoundImage" src={robo} />
        <h1 className="headingPrimary headingColor">404 Oops!</h1>
        <h2 className="headingMedium text-white margin-zero">Page Not Found</h2>
      </div>
    </div>
  );
};

export default NotFound;
