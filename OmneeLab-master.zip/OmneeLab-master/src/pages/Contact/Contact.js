import React, { useState } from "react";

import * as emailjs from "emailjs-com";

import GoogleMapReact from "google-map-react";

import "./Contact.scss";

const Contact = (props) => {
  const [name, setName] = useState("");
  const [company, setCompany] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    let templateParams = {
      email: email,
      message: message,
      phone: phone,
      name: name,
      company: company,
    };
    emailjs.send(
      "service_6lv36bh",
      "template_h5tntwm",
      templateParams,
      "user_QemBMiyn6c4gRNJYtfmsi"
    );

    setEmail("");
    setMessage("");
    setPhone("");
    setName("");
    setCompany("");

    let replyParams = {
      email: email,
      subject: "Omneelab Contact Form",
      to_name: name,
    };

    emailjs.send(
      "service_dasl0wi",
      "template_57mrsoa",
      replyParams,
      "user_y7tMzoMvMclRNQIq4Ny0y"
    );

    document.querySelector("#submitMessage").textContent =
      "Your Message has been Received. Our team will get back you.";
    document.querySelector("#submitMessage").style.opacity = "1";
    setTimeout(() => {
      document.querySelector("#submitMessage").textContent = "";
      document.querySelector("#submitMessage").style.opacity = "0";
    }, 5000);
  };

  return (
    <div className="contactContainer text-center">
      <h1 className="headingPrimary  margin-zero">
        Let us Take it to the Next Level
      </h1>
      <h2 className="headingSecondary headingColor">
        Have a Query? Reach us at -
      </h2>

      <div className="contactInfoContainer ">
        <div className="contactInfo">
          {/* <GoogleMapReact
            bootstrapURLKeys={{
              key: "AIzaSyBF0LcBBH9FHa3bXIcO3xmsfPz8AGadcso",
            }}
            defaultCenter={{ lat: 59.95, lng: 30.33 }}
            defaultZoom={11}
          /> */}
          <i className="fas fa-envelope"></i>
          <a href="mailto:info@omneelab.com">info@omneelab.com</a>
          <i className="fas fa-phone-alt"></i>
          <a href="tel:+919958123820">+91 9958123820</a>
        </div>
        <div className="formContainer">
          <form className="contactForm" onSubmit={(e) => handleSubmit(e)}>
            <input
              required
              placeholder="Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            ></input>
            <input
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Phone"
            ></input>
            <input
              required
              value={company}
              onChange={(e) => setCompany(e.target.value)}
              placeholder="Company Name"
            ></input>
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Business Email"
            ></input>
            <textarea
              required
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Message"
            ></textarea>
            <button
              type="submit"
              className="btn btn--primary contactFormButton"
            >
              Submit
            </button>
          </form>

          <h2 className="submitMessage" id="submitMessage"></h2>
        </div>
      </div>
    </div>
  );
};

export default Contact;
