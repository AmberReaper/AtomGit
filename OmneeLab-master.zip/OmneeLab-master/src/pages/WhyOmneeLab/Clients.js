import React from "react";

import "./Clients.scss";

import Genex from "../../assets/images/Clients/genex.png";
import Arguslogistics from "../../assets/images/Clients/arguslogistics.png";
import Edac from "../../assets/images/Clients/edac.png";
import Lagirl from "../../assets/images/Clients/lagirl.png";
import Shell from "../../assets/images/Clients/shell.png";
import Fliplearn from "../../assets/images/Clients/fliplearn.png";
import Warehousity from "../../assets/images/Clients/warehousity.png";
import Wetnwild from "../../assets/images/Clients/wetnwild.png";

const Clients = () => {
  return (
    <div className="clients">
      <h1 className="headingPrimary margin-zero">Our Clients</h1>
      <h2 className="headingSecondary headingColor">
        We aim to build long lasting partnerships with our clients
      </h2>

      <div className="integrationsList">
        <img src={Genex}></img>
        <img src={Arguslogistics}></img>
        <img src={Edac}></img>

        <img src={Lagirl}></img>
        <img src={Shell}></img>
        <img src={Fliplearn}></img>

        <img src={Warehousity}></img>
        <img src={Wetnwild}></img>
      </div>
    </div>
  );
};

export default Clients;
