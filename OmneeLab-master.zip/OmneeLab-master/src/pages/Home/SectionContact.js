import React from "react";
import { Link } from "react-router-dom";

import "./SectionContact.scss";

import DashboardDesktop from "../../assets/images/dashboard-desktop.png";

const SectionContact = () => {
  return (
    <div className="sectionContact">
      <div className="col-1-of-2 rightContainer">
        <h1 className="headingPrimary text-white margin-zero">Get in Touch</h1>

        <hr className="hrPrimary"></hr>

        <p className="text-white normal-text productDef ">
          Dont Believe Us? Try it for yourself.
          <br /> Drop us a message today and get your WMS demo.
        </p>

        <Link to="/contact">
          <button className="btn btn--secondary ">Contact Us</button>
        </Link>
      </div>

      <div className="col-1-of-2 leftContainer">
        <div className="imagePhoneContainer">
          <img className="imagePhone" src={DashboardDesktop} alt="desktop" />
        </div>
      </div>
    </div>
  );
};
export default SectionContact;
