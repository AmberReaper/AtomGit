import team1 from "../../assets/images/team1.jpg";

const TeamMembers = [
  {
    name: "Naveen Rana",
    designation: "Senior Project Manager",
    linkedinUrl: "#",
    TwitterUrl: "#",
  },
  {
    name: "Krish Tiwari",
    designation: "Senior PHP Developer",
    linkedinUrl: "#",
    TwitterUrl: "#",
  },
  {
    name: "Mahboob Alam",
    designation: "Senior PHP Developer",
    linkedinUrl: "#",
    TwitterUrl: "#",
  },
];

export default TeamMembers;
