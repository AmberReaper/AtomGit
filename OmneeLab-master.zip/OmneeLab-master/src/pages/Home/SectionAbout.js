import React from "react";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";

import "./SectionAbout.scss";

import aboutTeams from "../../assets/images/about-team.jpg";
import aboutSolution from "../../assets/images/about-solution.jpg";

const SectionAbout = () => {
  const history = useHistory();

  const routeChange = (link) => {
    let path = `/${link}`;
    history.push(path);
  };

  return (
    <section id="sectionAbout" className="sectionAbout container">
      <div className="Heading text-center">
        <h2 className="headingSecondary text-uppercase font-bold headingColor margin-zero">
          Easy to Use
        </h2>
        <h1 className="headingPrimary ">
          Leave your Warehouse Management problems to us
        </h1>
      </div>

      <div className="aboutImages">
        <div className="imageContainer aboutImage1">
          <Link to="/contact">
            <div className="imageOverlay"></div>
            <h1 className="headingPrimary center text-white margin-zero text-center">
              Contact Us
            </h1>
          </Link>
        </div>

        <div className="imageContainer aboutImage2">
          <Link to="/whyomneelab">
            <div className="imageOverlay"></div>
            <h1 className="headingPrimary center text-white margin-zero text-center">
              Why Omneelab
            </h1>
          </Link>
        </div>
      </div>
      <div className=".doubleContent">
        <div className=""></div>
        <div className=""></div>
      </div>
    </section>
  );
};

export default SectionAbout;
