import React from "react";

import "./WhyOmneeLab.scss";

import SectionFeatures from "./SectionFeatures";
import Integrations from "./Integrations";
import Specifics from "./Specifics";

import Clients from "./Clients";

const WhyOmneeLab = () => {
  return (
    <div className="whyContainer text-center">
      <div className="whyHeader">
        <div className="headingContainerWhy center">
          <h1 className="headingMain text-white ">
            We believe in Building Relationships
          </h1>
          <h2 className="headingSecondary headingColor">
            Our Application is flexible, collaborative and transparent.
          </h2>
        </div>
      </div>
      <div className="work">
        <h1 className="headingPrimary margin-zero ">
          We have the solution you need
        </h1>
        <h2 className="headingSecondary headingColor">Our Inspiration</h2>
        <p className="text-black">
          After spending more than 15 years in the industry we realised that
          though there are number of WMS software products in the market but all
          of them were lacking one key ingredient or another; that makes a WMS
          truly remarkable. Some were simply short of functionality, while
          others had taken a rather complicated route to address some of the key
          challenges that industry faces. Some were not designed keeping in view
          user's ease of usage, while others were really hard and expensive to
          modify.
        </p>
      </div>

      <SectionFeatures />
      <Integrations />
      <Specifics />
      <Clients />
    </div>
  );
};

export default WhyOmneeLab;
