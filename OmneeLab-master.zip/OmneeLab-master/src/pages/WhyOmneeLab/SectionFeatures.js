import React from "react";

import "./SectionFeatures.scss";

import Features from "./FeaturesList";

const SectionFeatures = () => {
  return (
    <div className="featuresContainer">
      {Features.map((feat) => {
        return (
          <div key={feat.title} className="card">
            <i className={feat.icon}></i>
            <h1 className="cardHeading">{feat.title}</h1>
            <h2 className="cardDesc">{feat.desc}</h2>
          </div>
        );
      })}
    </div>
  );
};

export default SectionFeatures;
