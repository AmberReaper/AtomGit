const Testimonials = [
  {
    text:
      "The team is highly proficient and knows the industry and its challenges inside out. Clearly they are not just the software guys but have actually been on the other side of the fence and understand warehouse operations challenges very well. The solutions they provide are truly remarkable and to the point.",
    name: "Operations Manager",
    position: "a Leading Distributor",
  },
  {
    text:
      " team is highly proficient and knows the industry and its challenges inside out. Clearly they are not just the software guys but have actually been on the other side of the fence and understand warehouse operations challenges very well. The solutions they provide are truly remarkable and to the point.",
    name: "Operations Manager",
    position: "a Leading Distributor",
  },
  {
    text: "",
    name: "",
    position: "",
  },
  {
    text: "",
    name: "",
    position: "",
  },
];

export default Testimonials;
